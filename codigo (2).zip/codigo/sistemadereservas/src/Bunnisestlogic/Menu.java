package Bunnisestlogic;

import Common.Cliente;

public class Menu {

    public Menu() {
        Cliente cliente2 = new Cliente("hillary", "marin", "208620037", " 60878903");

        System.out.println("Cliente: " + cliente2.getinformacion());

    }

    

}